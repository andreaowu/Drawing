/** Automatically generated file. DO NOT MODIFY */
package edu.berkeley.cs160.andreawu.prog2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}